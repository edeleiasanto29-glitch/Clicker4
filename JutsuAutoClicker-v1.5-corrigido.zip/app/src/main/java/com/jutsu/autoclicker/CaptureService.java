package com.jutsu.autoclicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ScrollView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;

/** Captura a tela, valida a sequência OCR e envia os selos em ordem. */
public class CaptureService extends Service {
    private static final String CHANNEL = "jutsu_auto";
    private static final int NOTIFICATION_ID = 9;

    // O visor OCR é configurável pelo usuário e salvo em coordenadas normalizadas.

    private static final int STABLE_FRAMES = 2;
    private static final long ABSENCE_RESET_MS = 650L;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private WindowManager windowManager;

    private LinearLayout overlayRoot;
    private TextView overlayStatus;
    private TextView overlaySequence;
    private TextView overlayOcr;
    private TextView overlaySpeed;
    private TextView overlayLaunch;
    private TextView overlayCalibration;
    private Button pauseButton;
    private Button visorButton;
    private Button markersButton;
    private Button collapseButton;
    private Button settingsButton;
    private ScrollView panelScroll;
    private WindowManager.LayoutParams overlayParams;
    private OcrVisorView visorView;
    private WindowManager.LayoutParams visorParams;
    private SealMarkerView markerView;
    private WindowManager.LayoutParams markerParams;
    private boolean visorEditing = true;
    private boolean markersVisible = true;

    private boolean overlayExpanded = false;
    private boolean settingsExpanded = false;
    private boolean busy = false;
    private String candidateSequence = "";
    private int candidateHits = 0;
    private String lastAcceptedSequence = "";
    private long lastAcceptedSeenAt = 0L;
    private long cycleBusyUntil = 0L;
    private int width = 0;
    private int height = 0;
    private MediaProjection.Callback projectionCallback;
    private DisplayManager displayManager;
    private DisplayManager.DisplayListener displayListener;
    private int lastDisplayW = 0;
    private int lastDisplayH = 0;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        AppSettings.migrateV14(this);
        AppSettings.migrateV15(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (displayManager != null) {
            displayListener = new DisplayManager.DisplayListener() {
                @Override public void onDisplayAdded(int displayId) { }
                @Override public void onDisplayRemoved(int displayId) { }
                @Override public void onDisplayChanged(int displayId) {
                    handler.postDelayed(() -> syncOverlayGeometry(true), 120);
                }
            };
            displayManager.registerDisplayListener(displayListener, handler);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        promoteToForeground("Preparando captura…");
        if (intent == null) return START_NOT_STICKY;

        int result = intent.getIntExtra("resultCode", android.app.Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            //noinspection deprecation
            data = intent.getParcelableExtra("data");
        }

        if (result == android.app.Activity.RESULT_OK && data != null) {
            safeStartCapture(data);
        } else {
            showStatus("Captura não autorizada");
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void safeStartCapture(Intent data) {
        try {
            stopCaptureOnly();
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(android.app.Activity.RESULT_OK, data);
            if (projection == null) throw new IllegalStateException("MediaProjection nula");

            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    handler.post(() -> {
                        stopCaptureOnly();
                        showStatus("Captura encerrada pelo Android");
                    });
                }
            };
            projection.registerCallback(projectionCallback, handler);

            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            width = Math.max(1, dm.widthPixels);
            height = Math.max(1, dm.heightPixels);
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            display = projection.createVirtualDisplay(
                    "JutsuAutoClicker",
                    width, height, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            reader.setOnImageAvailableListener(this::handleFrame, handler);
            showOverlay();
            showOcrVisor();
            showSealMarkers();
            syncOverlayGeometry(true);
            showStatus("Posicione o VISOR sobre a sequência…");
        } catch (Throwable t) {
            showStatus("Erro ao iniciar captura: " + safeMessage(t));
            stopCaptureOnly();
            stopSelf();
        }
    }

    private void handleFrame(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null) return;
            if (AppSettings.isPaused(this) || busy) return;
            busy = true;
            Bitmap full = imageToBitmap(image);
            analyze(full);
        } catch (Throwable t) {
            busy = false;
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        int iw = image.getWidth();
        int ih = image.getHeight();
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * iw);
        int paddedWidth = iw + (pixelStride == 0 ? 0 : rowPadding / pixelStride);

        Bitmap full = Bitmap.createBitmap(paddedWidth, ih, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        full.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(full, 0, 0, iw, ih);
        full.recycle();
        width = iw;
        height = ih;
        return cropped;
    }

    private void analyze(Bitmap full) {
        int screenW = width;
        int screenH = height;

        int l1 = clamp((int) (screenW * AppSettings.getOcrLeft(this)), 0, Math.max(0, screenW - 2));
        int t1 = clamp((int) (screenH * AppSettings.getOcrTop(this)), 0, Math.max(0, screenH - 2));
        int r1 = clamp((int) (screenW * AppSettings.getOcrRight(this)), l1 + 2, screenW);
        int b1 = clamp((int) (screenH * AppSettings.getOcrBottom(this)), t1 + 2, screenH);

        // Fallback automático: tenta a faixa central superior onde o padrão aparece.
        // Ela evita que JUTSU, nomes de NPCs e outros textos virem falsos padrões.
        int l2 = clamp((int) (screenW * 0.16f), 0, Math.max(0, screenW - 2));
        int t2 = clamp((int) (screenH * 0.13f), 0, Math.max(0, screenH - 2));
        int r2 = clamp((int) (screenW * 0.84f), l2 + 2, screenW);
        int b2 = clamp((int) (screenH * 0.32f), t2 + 2, screenH);

        Bitmap crop1 = null;
        Bitmap crop2 = null;
        Bitmap scaled1 = null;
        Bitmap scaled2 = null;
        try {
            crop1 = Bitmap.createBitmap(full, l1, t1, r1 - l1, b1 - t1);
            crop2 = Bitmap.createBitmap(full, l2, t2, r2 - l2, b2 - t2);
            // 3x deixa as letras grandes o suficiente para o OCR mesmo em telas densas.
            scaled1 = Bitmap.createScaledBitmap(crop1, Math.max(1, crop1.getWidth() * 3),
                    Math.max(1, crop1.getHeight() * 3), true);
            scaled2 = createHighContrast(crop2, 3);
            crop1.recycle(); crop1 = null;
            crop2.recycle(); crop2 = null;
            full.recycle();

            final Bitmap input1 = scaled1;
            final Bitmap input2 = scaled2;
            final OcrBatch batch = new OcrBatch();

            recognizer.process(InputImage.fromBitmap(input1, 0))
                    .addOnSuccessListener(text -> {
                        batch.sequence1 = SealDetector.findSequence(text);
                        batch.raw1 = text.getText();
                    })
                    .addOnCompleteListener(task -> {
                        batch.pending--;
                        finishOcrBatch(batch, input1, input2);
                    });

            recognizer.process(InputImage.fromBitmap(input2, 0))
                    .addOnSuccessListener(text -> {
                        batch.sequence2 = SealDetector.findSequence(text);
                        batch.raw2 = text.getText();
                    })
                    .addOnCompleteListener(task -> {
                        batch.pending--;
                        finishOcrBatch(batch, input1, input2);
                    });
        } catch (Throwable t) {
            if (crop1 != null && !crop1.isRecycled()) crop1.recycle();
            if (crop2 != null && !crop2.isRecycled()) crop2.recycle();
            if (scaled1 != null && !scaled1.isRecycled()) scaled1.recycle();
            if (scaled2 != null && !scaled2.isRecycled()) scaled2.recycle();
            if (full != null && !full.isRecycled()) full.recycle();
            busy = false;
        }
    }

    private Bitmap createHighContrast(Bitmap source, int scale) {
        int w = Math.max(1, source.getWidth() * scale);
        int h = Math.max(1, source.getHeight() * scale);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(out);
        android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix(new float[]{
                1.65f, 0, 0, 0, -82,
                0, 1.65f, 0, 0, -82,
                0, 0, 1.65f, 0, -82,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, null, new android.graphics.Rect(0, 0, w, h), paint);
        return out;
    }

    private static final class OcrBatch {
        int pending = 2;
        String sequence1;
        String sequence2;
        String raw1;
        String raw2;
        boolean finished;
    }

    private void finishOcrBatch(OcrBatch batch, Bitmap input1, Bitmap input2) {
        if (batch.pending > 0 || batch.finished) return;
        batch.finished = true;
        if (!input1.isRecycled()) input1.recycle();
        if (!input2.isRecycled()) input2.recycle();

        String best = SealDetector.better(batch.sequence1, batch.sequence2);
        String raw = joinOcr(batch.raw1, batch.raw2);
        handleOcrResult(best, raw);
        busy = false;
    }

    private String joinOcr(String a, String b) {
        String aa = a == null ? "" : a.replace("\n", " ").trim();
        String bb = b == null ? "" : b.replace("\n", " ").trim();
        if (aa.isEmpty() && bb.isEmpty()) return "—";
        if (aa.equals(bb) || bb.isEmpty()) return aa;
        if (aa.isEmpty()) return bb;
        return aa + "  |  topo amplo: " + bb;
    }

    private void handleOcrResult(String sequence, String rawOcr) {
        long now = System.currentTimeMillis();
        overlayOcr(rawOcr);
        if (sequence == null || !SealDetector.isValid(sequence)) {
            overlaySequence("—");
            if (now - lastAcceptedSeenAt > ABSENCE_RESET_MS) lastAcceptedSequence = "";
            if (now - lastAcceptedSeenAt > 260) {
                candidateSequence = "";
                candidateHits = 0;
            }
            return;
        }

        if (sequence.equals(candidateSequence)) {
            candidateHits++;
        } else {
            candidateSequence = sequence;
            candidateHits = 1;
        }

        overlaySequence(sequence);
        if (sequence.equals(lastAcceptedSequence)) {
            lastAcceptedSeenAt = now;
            return;
        }
        if (candidateHits < STABLE_FRAMES || now < cycleBusyUntil) return;

        TapAccessibilityService service = TapAccessibilityService.instance;
        if (service == null) {
            showStatus("Acessibilidade não conectada");
            return;
        }

        int gap = AppSettings.getGap(this);
        int delay = AppSettings.getLaunchDelay(this);
        if (!service.tapSequence(sequence, width, height, gap)) {
            showStatus("Falha ao enviar os selos");
            return;
        }

        lastAcceptedSequence = sequence;
        lastAcceptedSeenAt = now;
        cycleBusyUntil = now + Math.max(300L, sequence.length() * (long) gap + delay + 180L);
        showStatus("✓ Selos executados: " + sequence);
    }

    private void overlaySequence(String seq) {
        if (overlaySequence != null) {
            handler.post(() -> overlaySequence.setText("Detectado: " + seq));
        }
    }

    private void overlayOcr(String raw) {
        if (overlayOcr == null) return;
        final String shown = raw == null ? "—" : raw.replace("\n", " ").trim();
        handler.post(() -> overlayOcr.setText("OCR viu: " + (shown.isEmpty() ? "—" : shown)));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Jutsu Auto Clicker", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Controle do leitor automático de jutsus");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void promoteToForeground(String text) {
        Notification notification = makeNotification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification makeNotification(String text) {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return builder.setContentTitle("Jutsu Auto Clicker")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat_jutsu)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showStatus(String text) {
        updateNotification(text);
        if (overlayStatus != null) {
            handler.post(() -> {
                overlayStatus.setText(AppSettings.isPaused(this) ? "⏸  PAUSADO" : "●  " + text);
                updateOverlayValues();
            });
        }
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, makeNotification(text));
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setMinHeight(dp(28));
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(bg(Color.rgb(28, 24, 58), 11, Color.rgb(90, 65, 150)));
        return b;
    }

    private int[] getOverlayDisplaySize() {
        try {
            if (Build.VERSION.SDK_INT >= 30 && windowManager != null) {
                android.graphics.Rect r = windowManager.getCurrentWindowMetrics().getBounds();
                if (r.width() > 0 && r.height() > 0) return new int[]{r.width(), r.height()};
            }
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            if (windowManager != null) {
                windowManager.getDefaultDisplay().getRealMetrics(dm);
                if (dm.widthPixels > 0 && dm.heightPixels > 0) return new int[]{dm.widthPixels, dm.heightPixels};
            }
        } catch (Throwable ignored) { }
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        return new int[]{Math.max(1, dm.widthPixels), Math.max(1, dm.heightPixels)};
    }

    private int getPanelScrollHeight() {
        int[] ds = getOverlayDisplaySize();
        return Math.max(dp(120), ds[1] - dp(50));
    }

    private void syncOverlayGeometry(boolean force) {
        if (windowManager == null) return;
        int[] ds = getOverlayDisplaySize();
        if (ds[0] <= 0 || ds[1] <= 0) return;
        boolean changed = force || ds[0] != lastDisplayW || ds[1] != lastDisplayH;
        if (!changed) return;
        lastDisplayW = ds[0]; lastDisplayH = ds[1];

        if (overlayRoot != null && overlayParams != null) {
            overlayParams.x = clamp((int)(ds[0] * AppSettings.getPanelLeft(this)), 0, Math.max(0, ds[0] - overlayRoot.getWidth()));
            int totalH = Math.max(dp(42), overlayRoot.getHeight());
            overlayParams.y = clamp((int)(ds[1] * AppSettings.getPanelTop(this)), 0, Math.max(0, ds[1] - Math.min(totalH, ds[1])));
            try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
            if (panelScroll != null) {
                panelScroll.getLayoutParams().height = getPanelScrollHeight();
                panelScroll.requestLayout();
            }
        }
        if (visorView != null && visorParams != null) {
            visorParams.x = clamp((int)(ds[0] * AppSettings.getOcrLeft(this)), 0, Math.max(0, ds[0] - visorParams.width));
            visorParams.y = clamp((int)(ds[1] * AppSettings.getOcrTop(this)), 0, Math.max(0, ds[1] - visorParams.height));
            visorParams.width = Math.max(dp(160), Math.min(visorParams.width, ds[0] - visorParams.x));
            visorParams.height = Math.max(dp(55), Math.min(visorParams.height, ds[1] - visorParams.y));
            try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
        }
        if (markerView != null) markerView.invalidate();
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        if (overlayRoot != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        final int panelWidth = dp(238);
        final int overlayWidth = dp(246);

        overlayRoot = new LinearLayout(this);
        overlayRoot.setOrientation(LinearLayout.VERTICAL);
        overlayRoot.setPadding(dp(4), dp(4), dp(4), dp(4));
        overlayRoot.setBackground(bg(Color.argb(242, 10, 8, 22), 14, Color.rgb(255, 50, 90)));

        FrameLayout header = new FrameLayout(this);
        header.setBackground(bg(Color.argb(255, 21, 17, 40), 12, Color.rgb(95, 70, 165)));

        SealLogoView logo = new SealLogoView(this);
        header.addView(logo, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.LEFT | Gravity.CENTER_VERTICAL));

        TextView title = label("JutsuAutoClicker • v1.5", 12);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setSingleLine(true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(dp(112), dp(36), Gravity.LEFT | Gravity.CENTER_VERTICAL);
        tp.leftMargin = dp(38);
        header.addView(title, tp);

        pauseButton = button(AppSettings.isPaused(this) ? "▶" : "Ⅱ");
        pauseButton.setTextSize(16);
        pauseButton.setContentDescription("Pausar ou continuar");
        pauseButton.setOnClickListener(v -> togglePause());
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        pp.rightMargin = dp(38);
        header.addView(pauseButton, pp);

        collapseButton = button("⌃");
        collapseButton.setTextSize(15);
        collapseButton.setContentDescription("Abrir ou fechar painel");
        collapseButton.setOnClickListener(v -> toggleExpanded());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(34), dp(36), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        cp.rightMargin = dp(2);
        header.addView(collapseButton, cp);

        // A faixa entre o logo e os botões é a alça: arraste para qualquer lado.
        View dragArea = new View(this);
        FrameLayout.LayoutParams dap = new FrameLayout.LayoutParams(dp(112), dp(36), Gravity.LEFT | Gravity.CENTER_VERTICAL);
        dap.leftMargin = dp(40);
        header.addView(dragArea, dap);
        attachDrag(dragArea);
        overlayRoot.addView(header, new LinearLayout.LayoutParams(overlayWidth, dp(42)));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(2), dp(4), dp(2), 0);
        panel.setVisibility(overlayExpanded ? View.VISIBLE : View.GONE);

        overlayStatus = label("● Iniciando…", 10);
        overlayStatus.setSingleLine(true);
        panel.addView(overlayStatus, new LinearLayout.LayoutParams(-1, dp(24)));

        overlaySequence = label("Detectado: —", 11);
        overlaySequence.setSingleLine(true);
        panel.addView(overlaySequence, new LinearLayout.LayoutParams(-1, dp(25)));

        overlayOcr = label("OCR: —", 8);
        overlayOcr.setSingleLine(true);
        overlayOcr.setEllipsize(android.text.TextUtils.TruncateAt.END);
        overlayOcr.setTextColor(Color.LTGRAY);
        panel.addView(overlayOcr, new LinearLayout.LayoutParams(-1, dp(22)));

        LinearLayout toolsRow = new LinearLayout(this);
        toolsRow.setOrientation(LinearLayout.HORIZONTAL);
        visorButton = button("👁 Visor");
        visorButton.setOnClickListener(v -> toggleVisorEditing());
        markersButton = button("◉ Selos ON");
        markersButton.setOnClickListener(v -> {
            markersVisible = !markersVisible;
            setMarkersVisible(markersVisible);
            markersButton.setText(markersVisible ? "◉ Selos ON" : "◯ Selos OFF");
        });
        toolsRow.addView(visorButton, new LinearLayout.LayoutParams(0, dp(34), 1));
        toolsRow.addView(markersButton, new LinearLayout.LayoutParams(0, dp(34), 1));
        panel.addView(toolsRow, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        settingsButton = button("⚙ Ajustes");
        settingsButton.setOnClickListener(v -> toggleSettings(panel));
        Button stop = button("■ Parar");
        stop.setOnClickListener(v -> stopSelf());
        actionRow.addView(settingsButton, new LinearLayout.LayoutParams(0, dp(34), 1));
        actionRow.addView(stop, new LinearLayout.LayoutParams(0, dp(34), 1));
        panel.addView(actionRow, new LinearLayout.LayoutParams(-1, dp(36)));

        final LinearLayout advanced = new LinearLayout(this);
        advanced.setOrientation(LinearLayout.VERTICAL);
        advanced.setVisibility(settingsExpanded ? View.VISIBLE : View.GONE);

        advanced.addView(valueRow("Intervalo", true), new LinearLayout.LayoutParams(-1, dp(34)));
        advanced.addView(valueRow("Lançamento", false), new LinearLayout.LayoutParams(-1, dp(34)));

        overlayCalibration = label("Calibração: X +0.0%   Y +0.0%", 9);
        overlayCalibration.setTextColor(Color.LTGRAY);
        advanced.addView(overlayCalibration, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout calRow = new LinearLayout(this);
        calRow.setOrientation(LinearLayout.HORIZONTAL);
        addCalButton(calRow, "X−", () -> adjustOffset(true, -0.005f));
        addCalButton(calRow, "X+", () -> adjustOffset(true, 0.005f));
        addCalButton(calRow, "Y−", () -> adjustOffset(false, -0.005f));
        addCalButton(calRow, "Y+", () -> adjustOffset(false, 0.005f));
        addCalButton(calRow, "↺", () -> AppSettings.resetCalibration(this));
        advanced.addView(calRow, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView tests = label("TESTAR SELOS", 9);
        tests.setTextColor(Color.rgb(220, 180, 255));
        advanced.addView(tests, new LinearLayout.LayoutParams(-1, dp(20)));
        LinearLayout sealRow1 = new LinearLayout(this);
        LinearLayout sealRow2 = new LinearLayout(this);
        addSealButton(sealRow1, 'Z'); addSealButton(sealRow1, 'V'); addSealButton(sealRow1, 'X');
        addSealButton(sealRow2, 'B'); addSealButton(sealRow2, 'C'); addSealButton(sealRow2, 'N');
        advanced.addView(sealRow1, new LinearLayout.LayoutParams(-1, dp(32)));
        advanced.addView(sealRow2, new LinearLayout.LayoutParams(-1, dp(32)));

        Button launchTest = button("✦ Testar lançamento");
        launchTest.setOnClickListener(v -> tapLaunchTest());
        advanced.addView(launchTest, new LinearLayout.LayoutParams(-1, dp(32)));

        panel.addView(advanced, new LinearLayout.LayoutParams(-1, -2));
        panelScroll = new ScrollView(this);
        panelScroll.setFillViewport(false);
        panelScroll.setClipToPadding(false);
        panelScroll.setPadding(0, 0, 0, 0);
        panelScroll.addView(panel, new ScrollView.LayoutParams(panelWidth, -2));
        panelScroll.setVisibility(overlayExpanded ? View.VISIBLE : View.GONE);
        overlayRoot.addView(panelScroll, new LinearLayout.LayoutParams(overlayWidth, getPanelScrollHeight()));

        overlayParams = new WindowManager.LayoutParams(
                overlayWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        int[] dsize = getOverlayDisplaySize();
        lastDisplayW = dsize[0]; lastDisplayH = dsize[1];
        overlayParams.x = clamp((int)(lastDisplayW * AppSettings.getPanelLeft(this)), 0, Math.max(0, lastDisplayW - overlayWidth));
        overlayParams.y = clamp((int)(lastDisplayH * AppSettings.getPanelTop(this)), 0, Math.max(0, lastDisplayH - dp(50)));

        try {
            windowManager.addView(overlayRoot, overlayParams);
            updateOverlayValues();
        } catch (Throwable t) {
            overlayRoot = null;
        }
    }

    private void toggleSettings(LinearLayout panel) {
        if (panel == null || panel.getChildCount() == 0) return;
        settingsExpanded = !settingsExpanded;
        View advanced = panel.getChildAt(panel.getChildCount() - 1);
        advanced.setVisibility(settingsExpanded ? View.VISIBLE : View.GONE);
        if (settingsButton != null) settingsButton.setText(settingsExpanded ? "⚙ Fechar ajustes" : "⚙ Ajustes");
        try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
    }

    private void showOcrVisor() {
        if (windowManager == null || visorView != null) return;
        visorView = new OcrVisorView(this);
        visorView.setListener(new OcrVisorView.Listener() {
            @Override public void onMoveDelta(int dx, int dy) {
                if (visorParams == null) return;
                int[] ds = getOverlayDisplaySize();
                visorParams.x = clamp(visorParams.x + dx, 0, Math.max(0, ds[0] - visorParams.width));
                visorParams.y = clamp(visorParams.y + dy, 0, Math.max(0, ds[1] - visorParams.height));
                saveVisorRect();
                try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
            }
            @Override public void onResizeDelta(int dw, int dh) {
                if (visorParams == null) return;
                int[] ds = getOverlayDisplaySize();
                visorParams.width = clamp(visorParams.width + dw, dp(160), Math.max(dp(160), ds[0] - visorParams.x));
                visorParams.height = clamp(visorParams.height + dh, dp(55), Math.max(dp(55), ds[1] - visorParams.y));
                saveVisorRect();
                try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
            }
        });
        int[] dsize = getOverlayDisplaySize();
        int dw = dsize[0], dh = dsize[1];
        int x = (int)(dw * AppSettings.getOcrLeft(this));
        int y = (int)(dh * AppSettings.getOcrTop(this));
        int w = Math.max(dp(180), (int)(dw * (AppSettings.getOcrRight(this)-AppSettings.getOcrLeft(this))));
        int h = Math.max(dp(55), (int)(dh * (AppSettings.getOcrBottom(this)-AppSettings.getOcrTop(this))));
        visorParams = new WindowManager.LayoutParams(w, h,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        visorParams.gravity = Gravity.TOP | Gravity.LEFT;
        visorParams.x = x; visorParams.y = y;
        try { windowManager.addView(visorView, visorParams); } catch (Throwable ignored) { visorView = null; }
    }

    private void saveVisorRect() {
        if (visorParams == null) return;
        int[] dsize = getOverlayDisplaySize();
        if (dsize[0] <= 0 || dsize[1] <= 0) return;
        float l = visorParams.x/(float)dsize[0], t = visorParams.y/(float)dsize[1];
        float r = (visorParams.x+visorParams.width)/(float)dsize[0], b = (visorParams.y+visorParams.height)/(float)dsize[1];
        AppSettings.setOcrRect(this,l,t,r,b);
    }

    private void toggleVisorEditing() {
        if (visorView == null || visorParams == null) return;
        visorEditing = !visorEditing;
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (!visorEditing) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        visorParams.flags = flags;
        try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
        if (visorButton != null) visorButton.setText(visorEditing ? "👁  Visor: EDITAR" : "🔒  Visor: TRAVADO");
        showStatus(visorEditing ? "Arraste/redimensione o visor para as letras" : "Visor travado • OCR ativo");
    }

    private void showSealMarkers() {
        if (windowManager == null || markerView != null) return;
        markerView = new SealMarkerView(this);
        markerParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        markerParams.gravity = Gravity.TOP | Gravity.LEFT;
        try { windowManager.addView(markerView, markerParams); } catch (Throwable ignored) { markerView = null; }
    }

    private void setMarkersVisible(boolean visible) {
        if (markerView != null) markerView.setVisibility(visible ? View.VISIBLE : View.GONE);
        showStatus(visible ? "Marcadores dos selos ligados" : "Marcadores dos selos ocultos");
    }

    private LinearLayout valueRow(String name, boolean gap) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView left = label(name, 11);
        TextView value = label("", 11);
        Button minus = button("−");
        Button plus = button("+");
        if (gap) {
            overlaySpeed = value;
            minus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) - 2); updateOverlayValues(); });
            plus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) + 2); updateOverlayValues(); });
        } else {
            overlayLaunch = value;
            minus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) - 10); updateOverlayValues(); });
            plus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) + 10); updateOverlayValues(); });
        }
        row.addView(left, new LinearLayout.LayoutParams(dp(68), dp(30)));
        row.addView(minus, new LinearLayout.LayoutParams(dp(34), dp(30)));
        row.addView(value, new LinearLayout.LayoutParams(0, dp(30), 1));
        row.addView(plus, new LinearLayout.LayoutParams(dp(34), dp(30)));
        return row;
    }

    private void addCalButton(LinearLayout row, String text, Runnable action) {
        Button b = button(text);
        b.setOnClickListener(v -> { action.run(); updateOverlayValues(); });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(30), 1));
    }

    private void addSealButton(LinearLayout row, final char seal) {
        Button b = button(String.valueOf(seal));
        b.setTextSize(14);
        b.setOnClickListener(v -> {
            TapAccessibilityService s = TapAccessibilityService.instance;
            if (s != null) s.tapSingle(seal, width, height);
            showStatus("Teste: selo " + seal);
        });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(30), 1));
    }

    private void tapLaunchTest() {
        TapAccessibilityService s = TapAccessibilityService.instance;
        if (s != null) s.tapLaunch(width, height);
        showStatus("Teste: lançamento");
    }

    private void togglePause() {
        boolean paused = !AppSettings.isPaused(this);
        AppSettings.setPaused(this, paused);
        if (!paused) {
            candidateSequence = "";
            candidateHits = 0;
            lastAcceptedSequence = "";
        }
        if (pauseButton != null) pauseButton.setText(paused ? "▶" : "Ⅱ");
        showStatus(paused ? "Pausado" : "Continuando…");
    }

    private void adjustOffset(boolean horizontal, float delta) {
        if (horizontal) AppSettings.setOffsetX(this, AppSettings.getOffsetX(this) + delta);
        else AppSettings.setOffsetY(this, AppSettings.getOffsetY(this) + delta);
    }

    private void updateOverlayValues() {
        if (overlaySpeed != null) overlaySpeed.setText(AppSettings.getGap(this) + " ms");
        if (overlayLaunch != null) overlayLaunch.setText(AppSettings.getLaunchDelay(this) + " ms");
        if (overlayCalibration != null) {
            overlayCalibration.setText(String.format(Locale.US, "Calibração: X %+.1f%%   Y %+.1f%%",
                    AppSettings.getOffsetX(this) * 100f, AppSettings.getOffsetY(this) * 100f));
        }
        if (pauseButton != null) pauseButton.setText(AppSettings.isPaused(this) ? "▶" : "Ⅱ");
        if (visorButton != null) visorButton.setText(visorEditing ? "👁 Visor" : "🔒 Visor");
        if (markersButton != null) markersButton.setText(markersVisible ? "◉ Selos ON" : "◯ Selos OFF");
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = overlayParams == null ? 0 : overlayParams.x;
                        startY = overlayParams == null ? 0 : overlayParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (overlayParams == null || windowManager == null || overlayRoot == null) return true;
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(3) || Math.abs(dy) > dp(3)) moved = true;
                        if (moved) {
                            int[] ds = getOverlayDisplaySize();
                            int maxX = Math.max(0, ds[0] - overlayRoot.getWidth());
                            int maxY = Math.max(0, ds[1] - overlayRoot.getHeight());
                            overlayParams.x = clamp(startX + (int) dx, 0, maxX);
                            overlayParams.y = clamp(startY + (int) dy, 0, maxY);
                            if (ds[0] > 0 && ds[1] > 0) {
                                AppSettings.setPanelPosition(CaptureService.this, overlayParams.x/(float)ds[0], overlayParams.y/(float)ds[1]);
                            }
                            try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void toggleExpanded() {
        if (overlayRoot == null || overlayRoot.getChildCount() < 2) return;
        View panel = overlayRoot.getChildAt(1);
        overlayExpanded = !overlayExpanded;
        panel.setVisibility(overlayExpanded ? View.VISIBLE : View.GONE);
        if (panelScroll != null) panelScroll.getLayoutParams().height = getPanelScrollHeight();
        if (collapseButton != null) collapseButton.setText(overlayExpanded ? "⌃" : "⌄");
        if (overlayRoot != null) overlayRoot.setClipChildren(false);
        try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
    }

    private boolean SettingsCanDrawOverlays() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private String safeMessage(Throwable t) {
        String m = t.getMessage();
        return m == null ? t.getClass().getSimpleName() : m;
    }

    private void removeOverlay() {
        if (windowManager != null && visorView != null) {
            try { windowManager.removeView(visorView); } catch (Throwable ignored) { }
        }
        if (windowManager != null && markerView != null) {
            try { windowManager.removeView(markerView); } catch (Throwable ignored) { }
        }
        visorView = null; visorParams = null; markerView = null; markerParams = null;
        if (windowManager != null && overlayRoot != null) {
            try { windowManager.removeView(overlayRoot); } catch (Throwable ignored) { }
        }
        overlayRoot = null;
        overlayStatus = null;
        overlaySequence = null;
        overlayOcr = null;
        overlaySpeed = null;
        overlayLaunch = null;
        overlayCalibration = null;
        pauseButton = null;
        visorButton = null;
        markersButton = null;
        collapseButton = null;
        settingsButton = null;
        panelScroll = null;
    }

    private void stopCaptureOnly() {
        if (reader != null) {
            try { reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
            try { reader.close(); } catch (Throwable ignored) { }
            reader = null;
        }
        if (display != null) {
            try { display.release(); } catch (Throwable ignored) { }
            display = null;
        }
        if (projection != null) {
            try {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
            } catch (Throwable ignored) { }
            try { projection.stop(); } catch (Throwable ignored) { }
            projection = null;
        }
        projectionCallback = null;
        busy = false;
    }

    @Override public void onDestroy() {
        if (displayManager != null && displayListener != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) { }
        }
        handler.removeCallbacksAndMessages(null);
        stopCaptureOnly();
        removeOverlay();
        if (recognizer != null) {
            try { recognizer.close(); } catch (Throwable ignored) { }
            recognizer = null;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

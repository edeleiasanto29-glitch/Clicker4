package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

/** Marcadores dos seis pontos de toque, sempre alinhados ao tamanho real do overlay. */
public class SealMarkerView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);

    public SealMarkerView(Context context) {
        super(context);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(2));
        ring.setColor(Color.rgb(180, 110, 255));
        fill.setColor(Color.argb(55, 70, 35, 160));
        label.setColor(Color.WHITE);
        label.setTextSize(dp(14));
        label.setTypeface(Typeface.DEFAULT_BOLD);
        setWillNotDraw(false);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        String[] keys = {"Z","V","X","B","C","N"};
        float[][] p = {
                {0.810f,0.112f},{0.895f,0.112f},
                {0.810f,0.276f},{0.895f,0.276f},
                {0.810f,0.460f},{0.895f,0.460f}
        };
        float ox = AppSettings.getOffsetX(getContext());
        float oy = AppSettings.getOffsetY(getContext());
        float r = dp(20);
        for (int i = 0; i < keys.length; i++) {
            float x = (p[i][0] + ox) * width;
            float y = (p[i][1] + oy) * height;
            c.drawCircle(x, y, r, fill);
            c.drawCircle(x, y, r, ring);
            c.drawText(keys[i], x - label.measureText(keys[i]) / 2f, y + dp(5), label);
        }
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}

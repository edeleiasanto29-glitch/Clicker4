package com.jutsu.autoclicker;

import com.google.mlkit.vision.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Extrai QUALQUER sequência formada pelos seis selos do minijogo: V, B, Z, X, C e N.
 * Não compara com uma lista fixa de combinações; somente normaliza erros comuns do OCR.
 */
public final class SealDetector {
    private static final Pattern VALID = Pattern.compile("[VBZXCN]{2,32}");
    private static final Pattern TOKEN = Pattern.compile("[A-Z0-9]+", Pattern.CASE_INSENSITIVE);
    private static final String SEALS = "VBZXCN";

    private SealDetector() {}

    public static String findSequence(Text text) {
        if (text == null) return null;
        String best = findSequenceInPlainText(text.getText());
        for (Text.TextBlock block : text.getTextBlocks()) {
            String blockCandidate = findSequenceInPlainText(block.getText());
            best = better(best, blockCandidate);
            for (Text.Line line : block.getLines()) {
                String candidate = findSequenceInPlainText(line.getText());
                best = better(best, candidate);
            }
        }
        return best;
    }

    /** Função pública para testes e diagnóstico offline. */
    public static String findSequenceInPlainText(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;

        String upper = raw.toUpperCase(Locale.US)
                .replace('Á', 'A').replace('Â', 'A').replace('Ã', 'A')
                .replace('À', 'A').replace('É', 'E').replace('Ê', 'E')
                .replace('Í', 'I').replace('Ó', 'O').replace('Ô', 'O')
                .replace('Õ', 'O').replace('Ú', 'U').replace('Ç', 'C');

        List<String> tokens = new ArrayList<>();
        Matcher m = TOKEN.matcher(upper);
        while (m.find()) {
            String normalized = normalizeToken(m.group());
            if (!normalized.isEmpty()) tokens.add(normalized);
        }

        String best = null;

        // Caso ideal: a sequência veio inteira em um token, por exemplo ZVBXCXCZ.
        for (String token : tokens) {
            best = better(best, tokenCandidate(token));
        }

        // OCR pode separar as letras: Z V B X C X C Z.
        StringBuilder singles = new StringBuilder();
        for (String token : tokens) {
            if (token.length() == 1 && allSealChars(token)) {
                singles.append(token);
                best = better(best, validPart(singles.toString()));
            } else {
                singles.setLength(0);
            }
        }

        // OCR também pode retornar pedaços: ZVB + XC + XCZ.
        for (int i = 0; i < tokens.size(); i++) {
            StringBuilder join = new StringBuilder();
            for (int j = i; j < Math.min(tokens.size(), i + 24); j++) {
                String token = tokens.get(j);
                if (!allSealChars(token) || token.length() > 32) break;
                join.append(token);
                best = better(best, validPart(join.toString()));
            }
        }

        // Última defesa: percorre o texto bruto e mantém qualquer run de selos,
        // tolerando espaços e pontuação entre as letras.
        StringBuilder run = new StringBuilder();
        for (int i = 0; i < upper.length(); i++) {
            char rawChar = upper.charAt(i);
            char c = normalizeChar(rawChar);
            if (isSealChar(c)) {
                if (run.length() < 32) run.append(c);
            } else if (rawChar == ' ' || rawChar == '\t' || rawChar == '-' || rawChar == '·'
                    || rawChar == '|' || rawChar == '_' || rawChar == ',' || rawChar == '.') {
                // separadores visuais são ignorados dentro do padrão;
                // limite de tamanho impede que duas regiões distantes se juntem para sempre.
                continue;
            } else {
                best = better(best, validPart(run.toString()));
                run.setLength(0);
            }
        }
        best = better(best, validPart(run.toString()));
        return best;
    }

    public static String normalizeToken(String token) {
        if (token == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < token.length(); i++) {
            char c = normalizeChar(token.charAt(i));
            // Mantém também caracteres normais para que palavras como JUTSU
            // não virem uma sequência de selos por acidente.
            out.append(c);
        }
        return out.toString();
    }

    private static char normalizeChar(char c) {
        switch (c) {
            // Confusões comuns do OCR com a fonte do minijogo.
            case 'Y': return 'V';
            case 'K': return 'X';
            case 'Q': return 'Z';
            case '2': return 'Z';
            case '8': return 'B';
            case '6': return 'C';
            default: return c;
        }
    }

    private static String tokenCandidate(String token) {
        return allSealChars(token) ? validPart(token) : null;
    }

    private static String validPart(String s) {
        return isValid(s) ? s : null;
    }

    public static boolean isValid(String s) {
        return s != null && VALID.matcher(s).matches();
    }

    public static boolean allSealChars(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            if (!isSealChar(s.charAt(i))) return false;
        }
        return true;
    }

    private static boolean isSealChar(char c) {
        return SEALS.indexOf(c) >= 0;
    }

    public static String better(String current, String candidate) {
        if (candidate == null) return current;
        if (current == null || candidate.length() > current.length()) return candidate;
        return current;
    }
}

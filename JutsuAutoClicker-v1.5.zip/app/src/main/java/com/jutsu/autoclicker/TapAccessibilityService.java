package com.jutsu.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

/** Envia toques na tela usando AccessibilityService.dispatchGesture. */
public class TapAccessibilityService extends AccessibilityService {
    public static volatile TapAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final int MAX_RETRIES = 2;

    // Calibrado a partir da captura real enviada pelo usuário (1536x691).
    private static final float Z_X = 0.810f, Z_Y = 0.112f;
    private static final float V_X = 0.895f, V_Y = 0.112f;
    private static final float X_X = 0.810f, X_Y = 0.276f;
    private static final float B_X = 0.895f, B_Y = 0.276f;
    private static final float C_X = 0.810f, C_Y = 0.460f;
    private static final float N_X = 0.895f, N_Y = 0.460f;

    @Override public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            // Preserva as capacidades declaradas no XML do serviço.
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.notificationTimeout = 100;
            setServiceInfo(info);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    public boolean tapSequence(String sequence, int width, int height, long gapMs) {
        if (Build.VERSION.SDK_INT < 24 || !SealDetector.isValid(sequence)) return false;
        if (width <= 0 || height <= 0 || AppSettings.isPaused(this)) return false;
        final long gap = Math.max(8, Math.min(120, gapMs));
        dispatchChunk(sequence, 0, width, height, gap, 0);
        return true;
    }

    private void dispatchChunk(final String sequence, final int from, final int width,
                               final int height, final long gap, final int attempt) {
        if (AppSettings.isPaused(this)) return;
        final int end = Math.min(sequence.length(), from + 6);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        long start = 0;
        int valid = 0;
        // Duração sempre menor que o intervalo para impedir toques simultâneos.
        final long duration = Math.max(2, Math.min(8, gap - 1));

        for (int i = from; i < end; i++) {
            float[] p = point(sequence.charAt(i), width, height);
            if (p == null) continue;
            Path path = new Path();
            path.moveTo(p[0], p[1]);
            builder.addStroke(new GestureDescription.StrokeDescription(path, start, duration));
            start += gap;
            valid++;
        }

        if (valid == 0) return;
        final boolean more = end < sequence.length();
        final long launchDelay = AppSettings.getLaunchDelay(this);

        boolean accepted;
        try {
            accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (AppSettings.isPaused(TapAccessibilityService.this)) return;
                    if (more) {
                        handler.postDelayed(() -> dispatchChunk(sequence, end, width, height, gap, 0), 6);
                    } else {
                        handler.postDelayed(() -> tapLaunch(width, height), launchDelay);
                    }
                }

                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (AppSettings.isPaused(TapAccessibilityService.this)) return;
                    if (attempt < MAX_RETRIES) {
                        handler.postDelayed(() -> dispatchChunk(sequence, from, width, height, gap, attempt + 1), 24);
                    }
                }
            }, handler);
        } catch (Throwable ignored) {
            accepted = false;
        }

        if (!accepted && attempt < MAX_RETRIES) {
            handler.postDelayed(() -> dispatchChunk(sequence, from, width, height, gap, attempt + 1), 24);
        }
    }

    private float[] point(char c, int width, int height) {
        float ox = AppSettings.getOffsetX(this);
        float oy = AppSettings.getOffsetY(this);
        switch (Character.toUpperCase(c)) {
            case 'Z': return new float[]{(Z_X + ox) * width, (Z_Y + oy) * height};
            case 'V': return new float[]{(V_X + ox) * width, (V_Y + oy) * height};
            case 'X': return new float[]{(X_X + ox) * width, (X_Y + oy) * height};
            case 'B': return new float[]{(B_X + ox) * width, (B_Y + oy) * height};
            case 'C': return new float[]{(C_X + ox) * width, (C_Y + oy) * height};
            case 'N': return new float[]{(N_X + ox) * width, (N_Y + oy) * height};
            default: return null;
        }
    }

    public void tapSingle(char key, int width, int height) {
        if (Build.VERSION.SDK_INT < 24 || AppSettings.isPaused(this)) return;
        float[] p = point(key, width, height);
        if (p == null) return;
        dispatchPoint(p[0], p[1]);
    }

    public void tapLaunch(int width, int height) {
        if (Build.VERSION.SDK_INT < 24 || AppSettings.isPaused(this)) return;
        dispatchPoint(width * AppSettings.getLaunchX(this), height * AppSettings.getLaunchY(this));
    }

    private void dispatchPoint(float x, float y) {
        Path path = new Path();
        path.moveTo(Math.max(1, x), Math.max(1, y));
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path, 0, 8));
        try { dispatchGesture(b.build(), null, handler); } catch (Throwable ignored) { }
    }
}
